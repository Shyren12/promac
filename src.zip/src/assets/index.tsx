import inan from "./inan.jpg";
import qr from "./qr.jpg";
export { inan, qr };
